const adTypes = {
  1: {
    name: 'Banner',
    width: 728,
    height: 90,
  },
  2: {
    name: 'SkyScraper',
    width: 160,
    height: 620,
  },
  3: {
    name: 'Box',
    width: 300,
    height: 270,
  },
}

export {
  adTypes,
}