const Theme2016 = props => {
  return <>
    <div id='theme-2016-enabled' />
    {props.children}
  </>
}

export default Theme2016;