namespace Roblox.Exceptions.Services.Users;

public class StatusTooLongException : System.Exception { }
public class StatusTooShortException : System.Exception { }