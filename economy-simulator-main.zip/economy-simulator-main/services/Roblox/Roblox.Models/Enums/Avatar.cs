namespace Roblox.Models.Avatar;

public enum AvatarType
{
    R6 = 1,
    R15,
}