namespace Roblox.Dto;

public class Total
{
    public int total { get; set; }
}