namespace Roblox.Dto.Users;

public class BadgeEntry
{
    public int id { get; set; }
    public string name { get; set; } = "Unknown Badge";
    public string description { get; set; } = "Unknown Badge";
}