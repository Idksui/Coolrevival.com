namespace Roblox.Dto.Users;

public class PasswordEntry
{
    public string password { get; set; }
}